/* CSCI200 Lab
 *
 * This program executes a sequence of tests that validate the common operations on arrays and linked lists.
 *
 * Copyright 2023 Dr. Jeffrey Paone
 */

Your task is to implement the functions declared in Array.hpp and LinkedList.hpp such that all of the tests within the test suite pass.