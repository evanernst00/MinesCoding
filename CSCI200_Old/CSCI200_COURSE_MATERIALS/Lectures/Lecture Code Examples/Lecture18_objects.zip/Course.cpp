#include "Course.h"

using namespace std;

Course::Course() {
    _title = "CSM 101";
    _enrollment = 0;
}

Course::Course(const string TITLE) {
    _title = TITLE;
    _enrollment = 0;
}

string Course::getTitle() {
    return _title;
}

int Course::getEnrollment() {
    return _enrollment;
}

void Course::registerStudent() {
    _enrollment++;
}

void Course::withdrawStudent() {
    if(_enrollment > 0) _enrollment--;
}