#include <iostream>
using namespace std;

//const float PI = 3.141f;

int main() { 
  int x = 4;
  cout << x << endl;   // prints 4
  //int z = 5;           // compiler error! redefinition of x
  if( true ) {
    int x = 2;         // ok, "shadows" prior declaration
    //int y = 3;
    cout << x << endl; // prints 2
  }
  cout << "Enter x: ";
  cin >> x; 
  cout << x << endl;   // prints 4
  if(x < 0) {
    return -1;
  }
  //cout << y << endl;   // compiler error! y undeclared
  for(int i = 0; i < 10; i++) {
    cout << "i = " << i << endl;
    cout << "x + i = " << x+i << endl;
  }
  return 0;
}

