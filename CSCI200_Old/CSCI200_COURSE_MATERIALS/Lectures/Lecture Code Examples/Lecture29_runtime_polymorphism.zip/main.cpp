#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Animal {
public:
    Animal() {
        cout << "Constructing Default Animal" << endl;
        _name = "Animal";
        mSpecies = "animalia";
    }
    virtual ~Animal() {
        cout << "Destroying Animal " << _name << endl;
    }
    string getName() const { return _name; }
    void setName(const string NAME) { 
        cout << "Setting name " << NAME << endl;
        _name = NAME; 
    }
    string getSpecies() const { return mSpecies; }
    void sleep() const { cout << "zzz" << endl; }
    virtual void speak() const { 
        cout << "..." << endl; 
    }
protected:
    string mSpecies;
private:
    string _name;
};

class Dog : public Animal {
public:
    Dog() {
        cout << "Constructing Default Dog" << endl;
        mSpecies = "canine";
    }
    ~Dog() {
        cout << "Destroying Dog " << getName() << endl;
    }
    void speak() const override {
        cout << "WOOF!" << endl;
    }
private:

};

class Cat : public Animal {
public:
    Cat() {
        cout << "Constructing Default Cat" << endl;
        mSpecies = "feline";
    }
    Cat(const Cat &OTHER) {
        cout << "Copy Constructing Cat" << endl;
        mSpecies = "feline";
        setName( OTHER.getName() );
    }
    ~Cat() {
        cout << "Destroying Cat " << getName() << endl;
    }
    void speak() const override {
        cout << "meow" << endl;
    }
private:

};

class Lion : public Cat {
public:
    Lion() {
        cout << "Constructing Default Lion" << endl;
        mSpecies = "leone";
        _numPounces = 3;
    }
    ~Lion() {
        cout << "Destroying Lion " << getName() << endl;
    }
    void speak() const override {
        cout << "ROAAARRRR" << endl;
    }
    void pounce() const {
        for(int i = 0; i < _numPounces; i++) {
            cout << "attack!" << endl;
        }
    }
private:
    int _numPounces;
};

int main() {

    Animal john;
    john.setName("John");
    cout << john.getName() << " is sleeping" << endl;
    cout << john.getName() << " is of type species " << john.getSpecies() << endl;
    john.sleep();
    john.speak();

    Dog odie;
    odie.setName("Odie");
    cout << odie.getName() << " is sleeping" << endl;
    cout << odie.getName() << " is of type species " << odie.getSpecies() << endl;
    odie.sleep();
    odie.speak();

    Cat garfield;
    garfield.setName("Garfield");
    cout << garfield.getName() << " is sleeping" << endl;
    garfield.sleep();
    garfield.speak();

    Lion simba;
    simba.setName("Simba");
    simba.pounce();
    simba.speak(); // using Lion speak - roar
    ((Cat)simba).speak(); // using Cat speak - meow
    simba.Cat::speak();
    simba.Animal::speak();

    vector<Animal*> menagerie(4);
    menagerie.at(0) = &john;
    menagerie.at(1) = &odie;
    menagerie.at(2) = &garfield;
    menagerie.at(3) = &simba;
    for(size_t i = 0; i < menagerie.size(); i++) {
        menagerie.at(i)->speak();

        // unsafe to cast since Lion::_numPounces does not exist on all objects we are pointing at
        // ( (Lion*) menagerie.at(i) )->pounce(); // uncomment to see broken behavior
    }

    Animal* pAnimal = new Lion;
    pAnimal->speak();
    delete pAnimal;
    
    return 0;
}