#include <iostream>
using namespace std;

int add(int x, int y) {
  int a;
  a = x + y;
  cout << "a: " << a << endl;
  return a;
}

int main() { 
  int a(4), b(3);
  cout << "a: " << a << endl;
  int c = add(a, b);
  cout << "c: " << c << endl;
  int d = add(5, 8);
  cout << "d: " << d << endl;
  return 0;
}

