#include <iostream>
using namespace std;

int main() {
    int x(3), y;
    cout << "Enter 1 for True and 0 for False: ";
    cin >> y;

    cout << "x is " << x << endl;
    cout << "y is " << y << endl << endl;

    cout << "Evaluating y && (x += 3): ";
    if( y && (x += 3) ) {
        cout << "True!" << endl;
    } else {
        cout << "False" << endl;
    }

    cout << "x is " << x << endl;
    cout << "y is " << y << endl;

    return 0;
}