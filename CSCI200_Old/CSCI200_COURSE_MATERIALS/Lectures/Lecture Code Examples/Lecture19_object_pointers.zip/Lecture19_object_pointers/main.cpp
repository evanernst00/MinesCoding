#include "Course.h"

#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<Course*> courseCatalog;
    courseCatalog.push_back( new Course() );
    courseCatalog.push_back( new Course("CSCI 200") );

    for(size_t i = 0; i < courseCatalog.size(); i++) {
        Course* pCurrentCourse = courseCatalog.at(i);
        pCurrentCourse->registerStudent();
        pCurrentCourse->registerStudent();
    }

    for(size_t i = 0; i < courseCatalog.size(); i++) {
        cout << setw(9) << right << courseCatalog.at(i)->getTitle() 
             << ": " << courseCatalog.at(i)->getEnrollment() << endl;
    }

    return 0;    
}
