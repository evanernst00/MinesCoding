#ifndef COURSE_H
#define COURSE_H

#include <string>

/**
 * @brief course with title and current enrollment
 * 
 */
class Course {
public:
    /**
     * @brief Construct a new Course object
     * @note initializes enrollment to zero and title to CSM 101
     */
    Course();
    /**
     * @brief Construct a new Course object with specified title
     * @note initializes enrollment to zero
     */
    Course(std::string);
    /**
     * @brief Get the Title object
     * 
     * @return std::string course title
     */
    std::string getTitle();
    /**
     * @brief Get the Enrollment object
     * 
     * @return int number of students currently enrolled
     */
    int getEnrollment();
    /**
     * @brief increments course enrollment by one
     * 
     */
    void registerStudent();
    /**
     * @brief decrements course enrollment by one
     * @note checks if enrollment is positive before unenrolling
     */
    void withdrawStudent();
private:
    /**
     * @brief course title
     * 
     */
    std::string _title;
    /**
     * @brief current course enrollment
     * 
     */
    int _enrollment;
};

#endif