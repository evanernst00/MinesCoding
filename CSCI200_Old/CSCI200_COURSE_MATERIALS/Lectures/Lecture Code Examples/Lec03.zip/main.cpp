#include <cstdlib>  // gives access to rand(), srand()
#include <ctime>    // gives access to time()
#include <iostream>
using namespace std;

int main() {
    cout << "Hello World!" << endl;
     
    cout << "How are you?" << endl;

    cout << "Max value is " << RAND_MAX << endl;
    cout << "The current time is " << time(0) << endl;

    srand( time(0) ); // seed the RNG
    rand();         // throw away the first value

    cout << rand() << endl;
    cout << rand() << endl;
    cout << rand() << endl;
    cout << rand() << endl;
    int randomValue = rand();
    cout << "random value is: " << randomValue << endl;

    return 0;
}