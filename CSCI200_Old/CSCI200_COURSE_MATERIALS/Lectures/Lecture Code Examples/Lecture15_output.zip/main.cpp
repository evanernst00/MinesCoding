#include <fstream>      // step 1 - gives access to ifstream and ofstream
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    // int x, y;
    // cout << "Enter two values: ";
    // cin >> x >> y;

    // cout << "x is \"" << x << "\"" << endl;
    // cout << "y is \"" << y << "\"" << endl;

    // step 2 - declare object
    ofstream fout;
    // step 3 - open the file
    fout.open("myData.txt", ios::app);
    // step 4 - check for error
    // reasons for failure
    //  - if the directory/path doesn't exist
    //  - don't have write permission
    //  - file is locked (in use by another program)
    //  - out of disk space
    if( fout.fail() ) {
        // print message and quit
        cerr << "cannot open file, shutting down" << endl;
        return -2;
    }

    // step 5 - write!
    fout << "This goes to the file!" << endl;
    int x = 15;
    fout << "Today is Lecture #" << x << endl;

    // step 6 - close the file
    fout.close();

    const int N = 2000000000;
    cout << fixed << setprecision(3);
    for(int i = 0; i < N; i++) {
        if(i % 1000000 == 0) {
            cout << "\rLooping ... " << setw(7) << i / (float)N * 100 << "% done" << flush;
        }
    }
    cout << "\rLooping ... " << setw(7) << 100.f << "% done!" << endl;

    return 0;
}