#include "Box.h"

#include <iostream>
using namespace std;

Box::Box() {
    cout << "Box() called" << endl;
    _length = 1.0;
    _width = 1.0;
    _height = 1.0;
}

Box::Box(double h, double w, double l) {
    cout << "Box(double, double, double) called" << endl;
    if(h > 0) _height = h;
    else _height = 1.0;

    if(w > 0) _width = w;
    else _width = 1.0;
    
    if(l > 0) _length = l;
    else _length = 1.0;
}

double Box::getHeight() { return _height; }
void Box::setHeight(double h) {
    if(h > 0) _height = h;
}

double Box::getWidth() { return _width; }
void Box::setWidth(double w) {
    if(w > 0) _width = w;
}

double Box::getLength() { return _length; }
void Box::setLength(double l) {
    if(l > 0) _length = l;
}

double Box::volume() {
    return _length * _width * _height;
}