#ifndef BOX_H
#define BOX_H

/**
 * @brief represents a box of positive dimensions
 * 
 */
class Box {
public:     // accessible inside & outside the class
    // methods - aka functions
    // constructor
    // 1) has no return type
    // 2) it's named after the class

    /**
     * @brief Construct a new Box object
     * with all dimensions set to 1
     * 
     */
    Box();  // default constructor

    Box(double h, double w, double l); // parameterized constructor

    // getters aka accessors
    double getHeight();
    double getWidth();
    double getLength();
    // setters aka mutators
    void setHeight(double h);
    void setWidth(double w);
    void setLength(double l);

    /**
     * @brief computes volume of the box
     * 
     * @return double volume
     */
    double volume();

private:    // accessible only inside class
    // data members - aka variables
    /**
     * @brief length of the box
     * 
     */
    double _length;
    /**
     * @brief width of the box
     * 
     */
    double _width;
    /**
     * @brief height of the box
     * 
     */
    double _height;
};

#endif