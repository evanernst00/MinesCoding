#include "Box.h"

#include <iostream>
using namespace std;

int main() {
    
    Box amazonBox = Box();  // explicitly call default constructor
    amazonBox.setHeight(4.5);
    amazonBox.setWidth(2.25);
    cout << "What is the length? ";
    double length;
    cin >> length;
    amazonBox.setLength(length);
    cout << "The volume is " << amazonBox.volume() << endl;

    Box ikeaBox;    // implicitly calling the default constructor
    cout << "The volume is " << ikeaBox.volume() << endl;

    Box walmartBox = Box(12.5, 4.5, 4.5);  // explicitly calling parameterized constuctor
    cout << "The volume is " << walmartBox.volume() << endl;

    Box upsBox(-2.5, -2.5, -2.5); // implicitly call parameterized constructor
    upsBox.setWidth(-2.5);
    cout << "The width is " << upsBox.getWidth() << endl;
    cout << "The volume is " << upsBox.volume() << endl;

    return 0;
}
