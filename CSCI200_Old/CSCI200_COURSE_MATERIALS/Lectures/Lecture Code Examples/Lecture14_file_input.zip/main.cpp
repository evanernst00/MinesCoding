#include <fstream>      // step 1 - include file stream library
#include <iostream>
using namespace std;

int main() {
    cout << "Hello World!" << endl;

    // step 2 - declare our file stream object
    ifstream fin;
    // step 3 - open the associated file
    // relative path - dataFiles/data.txt
    // absolute path - Z:/CSCI200/SectionC/.../data.txt
    fin.open( "data.txt" );

    // steps 2 & 3 - declare & open at once
    // ifstream fin( "data.txt" );

    // step 4 - check for an error
    // option 1 - fin.fail()
    // option 2 - !fin.is_open()
    // option 3 - !fin
    // reasons for failure:
    //  - file doesn't exist
    //  - path doesn't exist
    //  - may not have read permission
    if( fin.fail() ) {
        // print out an error message
        cerr << "Error opening file, shutting down" << endl;
        // end the program
        return -1;
    }

    // step 5 - read the data
    int firstValue, fifthValue;
    float secondValue;
    char thirdValue, fourthValue;

    fin >> firstValue >> secondValue 
        >> thirdValue >> fourthValue 
        >> fifthValue;
    cout << "Read in: " 
         << firstValue << secondValue 
         << thirdValue << fourthValue 
         << fifthValue << endl;

    int n;
    fin >> n;
    for(int i = 0; i < n; i++) {
        int x, y;
        fin >> x >> y;
        cout << "Read in coord (" << x << ", " << y << ")" << endl;
    }

    const int SENTINAL_VALUE = -9999;
    int value;
    while(true) {
        fin >> value;
        if(value == SENTINAL_VALUE) break;
        cout << "Just read in " << value << endl;
    }

    while( !fin.eof() ) {
        fin >> value;
        cout << "Last read was " << value << endl;
    }

    // step 6 - close the file
    fin.close();

    return 0;
}
