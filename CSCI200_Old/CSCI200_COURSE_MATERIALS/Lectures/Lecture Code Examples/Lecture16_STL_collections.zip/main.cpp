#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main() {
    // vector< int > myVec;
    // while(true) {
    //     cout << "Enter an integer (zero to quit): ";
        
    //     int x;
    //     cin >> x;

    //     if(x == 0) break;
    //     else if(x > 0) {
    //         myVec.push_back(x);
    //     }
    // }

    // cout << "Vector size: " << myVec.size() << endl;
    // for(size_t i = 0 ; i < myVec.size() ; i++ ) {
    //     cout << myVec.at(i) << " ";
    // }
    // cout << endl;

    // vector<char> sectionLetters, word;
    // sectionLetters.push_back( 'A' );
    // sectionLetters.push_back( 'B' );
    // sectionLetters.push_back( 'F' );
    // sectionLetters.push_back( 'C' );
    // sectionLetters.push_back( 'D' );
    // sectionLetters.push_back( 'E' );

    // word.push_back( 'H' );
    // word.push_back( 'E' );
    // word.push_back( 'L' );
    // word.push_back( 'L' );
    // word.push_back( 'O' );

    string myStr;
    cout << "Enter a string: ";
    //cin >> myStr;
    getline(cin, myStr);
    cout << "You entered: \"" << myStr << "\"" << endl;
    cout << "It has " << myStr.length() << " characters." << endl;

    return 0;
}