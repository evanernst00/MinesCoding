#include <iostream>
#include <string>
using namespace std;

class Animal {
public: // accessible everywhere
    Animal() { 
        _name = "animal";
        mSpecies = "animalia";
        cout << "Animal() created " << _name << endl; 
    }
    ~Animal() { cout << "~Animal() destroyed " << _name << endl; }
    string getName() const { return _name; }
    void setName(const string NEW_NAME) { _name = NEW_NAME; }
    string getSpecies() const { return mSpecies; }
protected: // accessible in Animal and its children
    string mSpecies;
private: // only accessible in Animal
    string _name;
};

class Dog : public Animal {
public:
    Dog() { 
        cout << "Dog() created " << getName() << endl; 
        mSpecies = "canine"; 
    }
    ~Dog() { cout << "~Dog() destroyed " << getName() << endl; }
    string bark() const { return "ruff"; }
};

class Wolf : public Dog {
public:
    Wolf() { cout << "Wolf() created " << getName() << endl; }
    ~Wolf() { cout << "~Wolf() destroyed " << getName() << endl; }
};

class GreyWolf : public Wolf {
public:
    GreyWolf() { cout << "GreyWolf() created " << getName() << endl; }
    ~GreyWolf() { cout << "~GreyWolf() destroyed " << getName() << endl; }
};

class Cat : public Animal {
public:
    Cat() { 
        cout << "Cat() created " << getName() << endl; 
        mSpecies = "feline";
    }
    ~Cat() { cout << "~Cat() destroyed " << getName() << endl; }
    string meow() const { return "meow"; }
};

int main() {
    Animal animal;
    cout << animal.getName() << " plays the drums" << endl;

    cout << endl;
    Dog odie;
    odie.setName("Odie");
    cout << odie.getName() << " says " << odie.bark() << endl;
    cout << odie.getName() << " is a " << odie.getSpecies() << endl;

    cout << endl;
    Cat garfield;
    garfield.setName("Garfield");
    cout << garfield.getName() << " says " << garfield.meow() << endl;
    cout << garfield.getName() << " is a " << garfield.getSpecies() << endl;

    cout << endl;
    GreyWolf greyWolf;
    greyWolf.setName("Akela");
    cout << greyWolf.getName() << " says " << greyWolf.bark() << endl;
    cout << garfield.getName() << " is a " << garfield.getSpecies() << endl;

    cout << endl;

    return 0;
}