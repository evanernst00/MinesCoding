#include <iostream>
using namespace std;


// output aka return type name( input aka parameters )
// returnType name( param list ) { function body }

// lowerCamelCase     - variable
// UPPER_SNAKE_CASE   - constant
// lower_snake_case() - global functions

// function header
float compute_volume( float length, float width, float height ) {
    // function body / function definition
    return length * width * height;
}

void pretty_print_volume( float volume ) {
    cout << "The volume is " << volume << endl;
    // return; is optional
    return;
}

int main() {
    float length, height, width;
    cout << "What are the dimensions? ";
    cin >> length >> height >> width;

    // function_call( argument list )
    float volume = compute_volume(length, height, width);
    pretty_print_volume(volume);

    cout << "What are the second box dimensions? ";
    cin >> length >> height >> width;

    volume = compute_volume(length, height, width);
    pretty_print_volume(volume);

    return 0;
}