#include "Functions.h"                     // include the file with the corresponding prototypes

int calculator_add( int x, int y ) {       // function definition
  return x + y;
}

int calculator_sub( int x, int y ) {
  return x - y;
}