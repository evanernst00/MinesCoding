#include "Coordinate.hpp"

Coordinate::Coordinate()
{
    x = 0;
    y = 0;
}

Coordinate::Coordinate(double x, double y) : x(x), y(y) 
{
}