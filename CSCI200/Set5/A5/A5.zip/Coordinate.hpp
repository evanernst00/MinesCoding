#ifndef COORDINATE_HPP
#define COORDINATE_HPP

struct Coordinate
{
    Coordinate();
    Coordinate(double x, double y);
    double x;
    double y;
};

#endif // COORDINATE_HPP